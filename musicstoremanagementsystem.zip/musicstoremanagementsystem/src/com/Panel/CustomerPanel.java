package com.Panel;

import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import com.util.DB;

public class CustomerPanel extends JPanel implements ActionListener {

	private JTable table;
	private DefaultTableModel model;

	private JButton loadBtn = new JButton("Load");
	private JButton addBtn = new JButton("Add");
	private JButton updateBtn = new JButton("Update");
	private JButton deleteBtn = new JButton("Delete");
	private JButton placeOrderBtn = new JButton("Place Order");

	private JComboBox<String> productCmb = new JComboBox<>();
	private JTextField quantityTxt = new JTextField();
	private JTextField totalPriceTxt = new JTextField();

	private int currentUserId;

	public CustomerPanel(int userId) throws Exception {
		this.currentUserId = userId;
		setLayout(null);

		// Table setup
		String[] columns = {"CustomerID", "Name", "Phone", "Email", "Address"};
		model = new DefaultTableModel(columns, 0);
		table = new JTable(model);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		JScrollPane sp = new JScrollPane(table);
		sp.setBounds(20, 60, 850, 320);
		add(sp);

		// Buttons
		loadBtn.setBounds(20, 10, 100, 30);
		addBtn.setBounds(140, 10, 100, 30);
		updateBtn.setBounds(260, 10, 100, 30);
		deleteBtn.setBounds(380, 10, 100, 30);
		placeOrderBtn.setBounds(500, 10, 130, 30);

		add(loadBtn); add(addBtn); add(updateBtn); add(deleteBtn); add(placeOrderBtn);

		loadBtn.addActionListener(this);
		addBtn.addActionListener(this);
		updateBtn.addActionListener(this);
		deleteBtn.addActionListener(this);
		placeOrderBtn.addActionListener(this);

		// Order fields
		int y = 400;
		addField("Product:", productCmb, y); y += 40;
		addField("Quantity:", quantityTxt, y); y += 40;
		addField("Total Price:", totalPriceTxt, y);
		totalPriceTxt.setEditable(false);  // Total price is auto-calculated

		// Event listeners to auto-calculate total price
		productCmb.addActionListener(e -> updateTotalPrice());
		quantityTxt.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) { updateTotalPrice(); }
		});

		loadProducts();
		loadCustomers();
	}

	private void addField(String label, JComponent field, int y) {
		JLabel lbl = new JLabel(label);
		lbl.setBounds(20, y, 100, 25);
		field.setBounds(120, y, 200, 25);
		add(lbl);
		add(field);
	}

	private void updateTotalPrice() {
		int productId = getSelectedProductId();
		double price = getSelectedProductPrice();
		int qty = 0;
		try { qty = Integer.parseInt(quantityTxt.getText().trim()); } catch (Exception ignored) {}
		totalPriceTxt.setText(String.format("%.2f", price * qty));
	}

	private void loadProducts() throws Exception {
		try (Connection con = DB.getConnection()) {
			productCmb.removeAllItems();
			productCmb.addItem("-- Select Product --");
			PreparedStatement ps = con.prepareStatement("SELECT productid, name, price, stock FROM product ORDER BY name");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				productCmb.addItem(rs.getInt("productid") + " - " + rs.getString("name") + " - " + rs.getDouble("price") + " - Stock: " + rs.getInt("stock"));
			}
		}
	}

	private int getSelectedProductId() {
		String selected = (String) productCmb.getSelectedItem();
		if (selected != null && !selected.startsWith("--")) return Integer.parseInt(selected.split(" - ")[0]);
		return 0;
	}

	private double getSelectedProductPrice() {
		String selected = (String) productCmb.getSelectedItem();
		if (selected != null && !selected.startsWith("--")) return Double.parseDouble(selected.split(" - ")[2]);
		return 0;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		try (Connection con = DB.getConnection()) {
			if (e.getSource() == loadBtn) { loadCustomers(); }
			else if (e.getSource() == addBtn) { addCustomer(con); }
			else if (e.getSource() == updateBtn) { updateCustomer(con); }
			else if (e.getSource() == deleteBtn) { deleteCustomer(con); }
			else if (e.getSource() == placeOrderBtn) { placeOrder(con); }
		} catch (Exception ex) { ex.printStackTrace(); JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage()); }
	}

	private void placeOrder(Connection con) throws Exception {
		int selectedRow = table.getSelectedRow();
		if (selectedRow < 0) { JOptionPane.showMessageDialog(this, "Select a customer first!"); return; }

		int customerId = (int) model.getValueAt(selectedRow, 0);
		int productId = getSelectedProductId();
		if (productId == 0) { JOptionPane.showMessageDialog(this, "Select a product!"); return; }

		int quantity = 0;
		try { quantity = Integer.parseInt(quantityTxt.getText().trim()); } catch(Exception ex){ JOptionPane.showMessageDialog(this,"Invalid quantity"); return; }
		if (quantity <= 0) { JOptionPane.showMessageDialog(this,"Quantity must be greater than 0"); return; }

		double totalPrice = quantity * getSelectedProductPrice();

		// Check stock
		PreparedStatement stockCheck = con.prepareStatement("SELECT stock FROM product WHERE productid=?");
		stockCheck.setInt(1, productId);
		ResultSet rs = stockCheck.executeQuery();
		if (rs.next() && rs.getInt("stock") < quantity) { JOptionPane.showMessageDialog(this, "Not enough stock!"); return; }

		// Insert order
		PreparedStatement ps = con.prepareStatement("INSERT INTO sale (productid, customerid, userid, quantity, total_price, sale_date) VALUES (?,?,?,?,?,NOW())");
		ps.setInt(1, productId); ps.setInt(2, customerId); ps.setInt(3, currentUserId);
		ps.setInt(4, quantity); ps.setDouble(5, totalPrice); ps.executeUpdate();

		// Reduce stock
		PreparedStatement updateStock = con.prepareStatement("UPDATE product SET stock=stock-? WHERE productid=?");
		updateStock.setInt(1, quantity); updateStock.setInt(2, productId);
		updateStock.executeUpdate();

		JOptionPane.showMessageDialog(this, "Order placed successfully!");
		quantityTxt.setText(""); totalPriceTxt.setText("");
		loadProducts();
	}

	// --- Customer CRUD methods ---
	private void addCustomer(Connection con) throws SQLException {
		String name = JOptionPane.showInputDialog(this,"Enter customer name:");
		if (name == null || name.trim().isEmpty()) return;
		PreparedStatement ps = con.prepareStatement("INSERT INTO customer (name) VALUES (?)");
		ps.setString(1, name); ps.executeUpdate();
		loadCustomers();
	}

	private void updateCustomer(Connection con) throws SQLException {
		int selectedRow = table.getSelectedRow();
		if (selectedRow < 0) { JOptionPane.showMessageDialog(this,"Select a customer to update!"); return; }
		int customerId = (int) model.getValueAt(selectedRow, 0);
		String name = JOptionPane.showInputDialog(this,"Update customer name:", model.getValueAt(selectedRow,1));
		if (name == null || name.trim().isEmpty()) return;
		PreparedStatement ps = con.prepareStatement("UPDATE customer SET name=? WHERE customerid=?");
		ps.setString(1, name); ps.setInt(2, customerId); ps.executeUpdate();
		loadCustomers();
	}

	private void deleteCustomer(Connection con) throws SQLException {
		int selectedRow = table.getSelectedRow();
		if (selectedRow < 0) { JOptionPane.showMessageDialog(this,"Select a customer to delete!"); return; }
		int customerId = (int) model.getValueAt(selectedRow, 0);
		int confirm = JOptionPane.showConfirmDialog(this,"Are you sure you want to delete this customer?","Confirm Delete",JOptionPane.YES_NO_OPTION);
		if (confirm != JOptionPane.YES_OPTION) return;
		PreparedStatement ps = con.prepareStatement("DELETE FROM customer WHERE customerid=?");
		ps.setInt(1, customerId); ps.executeUpdate();
		loadCustomers();
	}

	private void loadCustomers() {
		try (Connection con = DB.getConnection()) {
			model.setRowCount(0);
			PreparedStatement ps = con.prepareStatement("SELECT customerid, name, phone, email, address FROM customer ORDER BY customerid");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				model.addRow(new Object[] {
						rs.getInt("customerid"),
						rs.getString("name"),
						rs.getString("phone"),
						rs.getString("email"),
						rs.getString("address")
				});
			}
		} catch(Exception ex){ ex.printStackTrace(); }
	}
}
