package com.Panel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.util.DB;

public class PaymentPanel extends JPanel implements ActionListener {

    private JTextField idtxt = new JTextField();
    private JTextField saleidtxt = new JTextField();
    private JTextField amounttxt = new JTextField();
    private JTextField paymentDatetxt = new JTextField();

    private JButton loadBtn = new JButton("Load Payments");
    private JButton addBtn = new JButton("Add Payment");
    private JButton updateBtn = new JButton("Update Payment");
    private JButton deleteBtn = new JButton("Delete Payment");

    private JTable table;
    private DefaultTableModel model;

    public PaymentPanel() throws Exception {
        setLayout(null);
        setBackground(new Color(245, 245, 245));

        // Fields
        int y = 20;
        addField("Payment ID", idtxt, y); idtxt.setEnabled(false); y += 40;
        addField("Sale ID", saleidtxt, y); y += 40;
        addField("Amount", amounttxt, y); y += 40;
        addField("Payment Date (YYYY-MM-DD)", paymentDatetxt, y); y += 50;

        // Buttons
        loadBtn.setBounds(300, y, 130, 35);
        addBtn.setBounds(450, y, 130, 35);
        updateBtn.setBounds(600, y, 130, 35);
        deleteBtn.setBounds(750, y, 130, 35);

        add(loadBtn);
        add(addBtn);
        add(updateBtn);
        add(deleteBtn);

        loadBtn.addActionListener(this);
        addBtn.addActionListener(this);
        updateBtn.addActionListener(this);
        deleteBtn.addActionListener(this);

        // Table
        String[] columns = {"Payment ID", "Sale ID", "Amount", "Payment Date"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(173, 216, 230));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 270, 860, 350);
        add(scrollPane);

        // Click table row → populate fields
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                idtxt.setText(model.getValueAt(row, 0).toString());
                saleidtxt.setText(model.getValueAt(row, 1).toString());
                amounttxt.setText(model.getValueAt(row, 2).toString());
                paymentDatetxt.setText(model.getValueAt(row, 3).toString());
            }
        });

        // Load payments on start
        loadPayments();
    }

    private void addField(String label, JComponent field, int y) {
        JLabel l = new JLabel(label);
        l.setBounds(20, y, 200, 25);
        l.setFont(new Font("Arial", Font.BOLD, 14));
        field.setBounds(220, y, 200, 25);
        add(l);
        add(field);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == loadBtn) loadPayments();
            else if (e.getSource() == addBtn) addPayment();
            else if (e.getSource() == updateBtn) updatePayment();
            else if (e.getSource() == deleteBtn) deletePayment();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void loadPayments() throws Exception {
        try (Connection con = DB.getConnection()) {
            model.setRowCount(0);
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM payment");
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("paymentid"),
                        rs.getInt("saleid"),
                        rs.getDouble("amount"),
                        rs.getDate("paymentdate")
                });
            }
        }
    }

    private void addPayment() throws Exception {
        try (Connection con = DB.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO payment(saleid, amount, paymentdate) VALUES(?,?,?)");
            ps.setInt(1, Integer.parseInt(saleidtxt.getText()));
            ps.setDouble(2, Double.parseDouble(amounttxt.getText()));
            ps.setDate(3, Date.valueOf(paymentDatetxt.getText()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Payment added successfully!");
            loadPayments();
        }
    }

    private void updatePayment() throws Exception {
        if (idtxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a payment to update!");
            return;
        }
        try (Connection con = DB.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "UPDATE payment SET saleid=?, amount=?, paymentdate=? WHERE paymentid=?");
            ps.setInt(1, Integer.parseInt(saleidtxt.getText()));
            ps.setDouble(2, Double.parseDouble(amounttxt.getText()));
            ps.setDate(3, Date.valueOf(paymentDatetxt.getText()));
            ps.setInt(4, Integer.parseInt(idtxt.getText()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Payment updated successfully!");
            loadPayments();
        }
    }

    private void deletePayment() throws Exception {
        if (idtxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a payment to delete!");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this payment?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection con = DB.getConnection()) {
                PreparedStatement ps = con.prepareStatement(
                        "DELETE FROM payment WHERE paymentid=?");
                ps.setInt(1, Integer.parseInt(idtxt.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Payment deleted successfully!");
                loadPayments();
            }
        }
    }
}
