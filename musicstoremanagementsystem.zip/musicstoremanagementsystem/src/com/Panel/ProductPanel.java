package com.Panel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.util.DB;

public class ProductPanel extends JPanel implements ActionListener {

    private JTextField idtxt = new JTextField();
    private JTextField nametxt = new JTextField();
    private JTextField pricetxt = new JTextField();
    private JTextField supplieridtxt = new JTextField();

    private JButton loadBtn = new JButton("Load Products");
    private JButton addBtn = new JButton("Add Product");
    private JButton updateBtn = new JButton("Update Product");
    private JButton deleteBtn = new JButton("Delete Product");

    private JTable table;
    private DefaultTableModel model;

    private int userId; // optional: who is adding/editing

    public ProductPanel(int userId) throws Exception {
        this.userId = userId;

        setLayout(null);
        setBackground(new Color(245, 245, 245));

        // Fields
        int y = 20;
        addField("Product ID", idtxt, y); idtxt.setEnabled(false); y += 40;
        addField("Name", nametxt, y); y += 40;
        addField("Price", pricetxt, y); y += 40;
        addField("Supplier ID", supplieridtxt, y); y += 50;

        // Buttons
        loadBtn.setBounds(350, 140, 130, 30);
        addBtn.setBounds(350, 20, 130, 30);
        updateBtn.setBounds(350, 60, 130, 30);
        deleteBtn.setBounds(350, 100, 130, 30);

        add(loadBtn);
        add(addBtn);
        add(updateBtn);
        add(deleteBtn);

        loadBtn.addActionListener(this);
        addBtn.addActionListener(this);
        updateBtn.addActionListener(this);
        deleteBtn.addActionListener(this);

        // Table
        String[] columns = {"Product ID", "Name", "Price", "Supplier ID"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(173, 216, 230));
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 180, 860, 350);
        add(scrollPane);

        // Click row → fill fields
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                idtxt.setText(model.getValueAt(row, 0).toString());
                nametxt.setText(model.getValueAt(row, 1).toString());
                pricetxt.setText(model.getValueAt(row, 2).toString());
                supplieridtxt.setText(model.getValueAt(row, 3).toString());
            }
        });

        // Load products on start
        loadProducts();
    }

    private void addField(String label, JComponent field, int y) {
        JLabel l = new JLabel(label);
        l.setBounds(20, y, 100, 25);
        l.setFont(new Font("Arial", Font.BOLD, 14));
        field.setBounds(130, y, 200, 25);
        add(l);
        add(field);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == loadBtn) loadProducts();
            else if (e.getSource() == addBtn) addProduct();
            else if (e.getSource() == updateBtn) updateProduct();
            else if (e.getSource() == deleteBtn) deleteProduct();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void loadProducts() throws Exception {
        try (Connection con = DB.getConnection()) {
            model.setRowCount(0);
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM product");
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("productid"),
                        rs.getString("name"),
                        rs.getDouble("price"),
                        rs.getInt("supplierid")
                });
            }
        }
    }

    private void addProduct() throws Exception {
        try (Connection con = DB.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO product(name, price, supplierid) VALUES(?,?,?)");
            ps.setString(1, nametxt.getText());
            ps.setDouble(2, Double.parseDouble(pricetxt.getText()));
            ps.setInt(3, Integer.parseInt(supplieridtxt.getText()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Product added successfully!");
            loadProducts();
        }
    }

    private void updateProduct() throws Exception {
        if (idtxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a product to update!");
            return;
        }
        try (Connection con = DB.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "UPDATE product SET name=?, price=?, supplierid=? WHERE productid=?");
            ps.setString(1, nametxt.getText());
            ps.setDouble(2, Double.parseDouble(pricetxt.getText()));
            ps.setInt(3, Integer.parseInt(supplieridtxt.getText()));
            ps.setInt(4, Integer.parseInt(idtxt.getText()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Product updated successfully!");
            loadProducts();
        }
    }

    private void deleteProduct() throws Exception {
        if (idtxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a product to delete!");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this product?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection con = DB.getConnection()) {
                PreparedStatement ps = con.prepareStatement(
                        "DELETE FROM product WHERE productid=?");
                ps.setInt(1, Integer.parseInt(idtxt.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Product deleted successfully!");
                loadProducts();
            }
        }
    }
}
