package com.Panel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.util.DB;

public class SupplierPanel extends JPanel implements ActionListener {

    private JTextField idtxt = new JTextField();
    private JTextField nametxt = new JTextField();
    private JTextField emailtxt = new JTextField();
    private JTextField phonetxt = new JTextField();

    private JButton loadBtn = new JButton("Load Suppliers");
    private JButton addBtn = new JButton("Add Supplier");
    private JButton updateBtn = new JButton("Update Supplier");
    private JButton deleteBtn = new JButton("Delete Supplier");

    private JTable table;
    private DefaultTableModel model;

    public SupplierPanel() throws Exception {
        setLayout(null);
        setBackground(new Color(245, 245, 245));

        // Fields
        int y = 20;
        addField("Supplier ID", idtxt, y); idtxt.setEnabled(false); y += 40;
        addField("Name", nametxt, y); y += 40;
        addField("Email", emailtxt, y); y += 40;
        addField("Phone", phonetxt, y); y += 50;

        // Buttons
        loadBtn.setBounds(350, 140, 130, 30);
        addBtn.setBounds(350, 20, 130, 30);
        updateBtn.setBounds(350, 60, 130, 30);
        deleteBtn.setBounds(350, 100, 130, 30);

        add(loadBtn);
        add(addBtn);
        add(updateBtn);
        add(deleteBtn);

        loadBtn.addActionListener(this);
        addBtn.addActionListener(this);
        updateBtn.addActionListener(this);
        deleteBtn.addActionListener(this);

        // Table
        String[] columns = {"Supplier ID", "Name", "Email", "Phone"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(173, 216, 230));
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 180, 860, 350);
        add(scrollPane);

        // Click row → fill fields
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                idtxt.setText(model.getValueAt(row, 0).toString());
                nametxt.setText(model.getValueAt(row, 1).toString());
                emailtxt.setText(model.getValueAt(row, 2).toString());
                phonetxt.setText(model.getValueAt(row, 3).toString());
            }
        });

        // Load suppliers on start
        loadSuppliers();
    }

    private void addField(String label, JComponent field, int y) {
        JLabel l = new JLabel(label);
        l.setBounds(20, y, 100, 25);
        l.setFont(new Font("Arial", Font.BOLD, 14));
        field.setBounds(130, y, 200, 25);
        add(l);
        add(field);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == loadBtn) loadSuppliers();
            else if (e.getSource() == addBtn) addSupplier();
            else if (e.getSource() == updateBtn) updateSupplier();
            else if (e.getSource() == deleteBtn) deleteSupplier();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void loadSuppliers() throws Exception {
        try (Connection con = DB.getConnection()) {
            model.setRowCount(0);
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM supplier");
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("supplierid"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("phone")
                });
            }
        }
    }

    private void addSupplier() throws Exception {
        try (Connection con = DB.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO supplier(name,email,phone) VALUES(?,?,?)");
            ps.setString(1, nametxt.getText());
            ps.setString(2, emailtxt.getText());
            ps.setString(3, phonetxt.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Supplier added successfully!");
            loadSuppliers();
        }
    }

    private void updateSupplier() throws Exception {
        if (idtxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a supplier to update!");
            return;
        }
        try (Connection con = DB.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "UPDATE supplier SET name=?, email=?, phone=? WHERE supplierid=?");
            ps.setString(1, nametxt.getText());
            ps.setString(2, emailtxt.getText());
            ps.setString(3, phonetxt.getText());
            ps.setInt(4, Integer.parseInt(idtxt.getText()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Supplier updated successfully!");
            loadSuppliers();
        }
    }

    private void deleteSupplier() throws Exception {
        if (idtxt.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a supplier to delete!");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this supplier?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection con = DB.getConnection()) {
                PreparedStatement ps = con.prepareStatement(
                        "DELETE FROM supplier WHERE supplierid=?");
                ps.setInt(1, Integer.parseInt(idtxt.getText()));
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Supplier deleted successfully!");
                loadSuppliers();
            }
        }
    }
}
