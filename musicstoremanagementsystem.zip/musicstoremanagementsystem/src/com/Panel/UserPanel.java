package com.Panel;

import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import com.util.DB;

public class UserPanel extends JPanel implements ActionListener {

	private JTextField userIdTxt = new JTextField();
	private JTextField usernameTxt = new JTextField();
	private JPasswordField passwordTxt = new JPasswordField();
	private JComboBox<String> roleCmb = new JComboBox<>(new String[]{"Admin", "Staff", "Cashier", "Customer"});
	private JTextField emailTxt = new JTextField();

	private JButton addBtn = new JButton("Add");
	private JButton updateBtn = new JButton("Update");
	private JButton deleteBtn = new JButton("Delete");
	private JButton loadBtn = new JButton("Load");

	private JTable table;
	private DefaultTableModel model;

	public UserPanel() {
		setLayout(null);

		String[] columns = {"UserID", "Username", "Password", "Role", "Email"};
		model = new DefaultTableModel(columns, 0);
		table = new JTable(model);

		JScrollPane sp = new JScrollPane(table);
		sp.setBounds(20, 200, 850, 300);
		add(sp);

		int y = 20;
		addField("User ID", userIdTxt, y); userIdTxt.setEditable(false); y += 30;
		addField("Username", usernameTxt, y); y += 30;
		addField("Password", passwordTxt, y); y += 30;
		addField("Role", roleCmb, y); y += 30;
		addField("Email", emailTxt, y); y += 30;

		addButtons();

		// Table row selection to fill fields
		table.getSelectionModel().addListSelectionListener(e -> {
			if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
				int row = table.getSelectedRow();
				userIdTxt.setText(model.getValueAt(row, 0).toString());
				usernameTxt.setText(model.getValueAt(row, 1).toString());
				passwordTxt.setText(model.getValueAt(row, 2).toString());
				roleCmb.setSelectedItem(model.getValueAt(row, 3).toString());
				emailTxt.setText(model.getValueAt(row, 4).toString());
			}
		});

		loadUsers();
	}

	private void addField(String label, JComponent field, int y) {
		JLabel l = new JLabel(label + ":");
		l.setBounds(20, y, 100, 25);
		field.setBounds(130, y, 150, 25);
		add(l);
		add(field);
	}

	private void addButtons() {
		addBtn.setBounds(300, 20, 100, 30);
		updateBtn.setBounds(300, 60, 100, 30);
		deleteBtn.setBounds(300, 100, 100, 30);
		loadBtn.setBounds(300, 140, 100, 30);

		add(addBtn);
		add(updateBtn);
		add(deleteBtn);
		add(loadBtn);

		addBtn.addActionListener(this);
		updateBtn.addActionListener(this);
		deleteBtn.addActionListener(this);
		loadBtn.addActionListener(this);
	}

	private void clearFields() {
		userIdTxt.setText("");
		usernameTxt.setText("");
		passwordTxt.setText("");
		roleCmb.setSelectedIndex(0);
		emailTxt.setText("");
		table.clearSelection();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		try (Connection con = DB.getConnection()) {
			if (e.getSource() == addBtn) addUser(con);
			else if (e.getSource() == updateBtn) updateUser(con);
			else if (e.getSource() == deleteBtn) deleteUser(con);
			else if (e.getSource() == loadBtn) loadUsers();
		} catch (Exception ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
		}
	}

	private void addUser(Connection con) throws SQLException {
		if (usernameTxt.getText().isEmpty() || passwordTxt.getPassword().length == 0 || emailTxt.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "All fields except ID are required!");
			return;
		}

		PreparedStatement check = con.prepareStatement("SELECT UserID FROM user WHERE username=?");
		check.setString(1, usernameTxt.getText());
		ResultSet rs = check.executeQuery();
		if (rs.next()) {
			JOptionPane.showMessageDialog(this, "Username already exists!");
			return;
		}

		PreparedStatement ps = con.prepareStatement("INSERT INTO user(username,password,role,email) VALUES(?,?,?,?)");
		ps.setString(1, usernameTxt.getText());
		ps.setString(2, new String(passwordTxt.getPassword()));
		ps.setString(3, roleCmb.getSelectedItem().toString());
		ps.setString(4, emailTxt.getText());

		if (ps.executeUpdate() > 0) {
			JOptionPane.showMessageDialog(this, "User added successfully!");
			clearFields();
			loadUsers();
		}
	}

	private void updateUser(Connection con) throws SQLException {
		if (userIdTxt.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Select a user to update!");
			return;
		}

		PreparedStatement ps = con.prepareStatement(
				"UPDATE user SET username=?, password=?, role=?, email=? WHERE userid=?");
		ps.setString(1, usernameTxt.getText());
		ps.setString(2, new String(passwordTxt.getPassword()));
		ps.setString(3, roleCmb.getSelectedItem().toString());
		ps.setString(4, emailTxt.getText());
		ps.setInt(5, Integer.parseInt(userIdTxt.getText()));

		if (ps.executeUpdate() > 0) {
			JOptionPane.showMessageDialog(this, "User updated successfully!");
			clearFields();
			loadUsers();
		}
	}

	private void deleteUser(Connection con) throws SQLException {
		if (userIdTxt.getText().isEmpty()) {
			JOptionPane.showMessageDialog(this, "Select a user to delete!");
			return;
		}

		int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this user?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
		if (confirm != JOptionPane.YES_OPTION) return;

		PreparedStatement ps = con.prepareStatement("DELETE FROM user WHERE userid=?");
		ps.setInt(1, Integer.parseInt(userIdTxt.getText()));

		if (ps.executeUpdate() > 0) {
			JOptionPane.showMessageDialog(this, "User deleted successfully!");
			clearFields();
			loadUsers();
		}
	}

	private void loadUsers() {
		try (Connection con = DB.getConnection()) {
			model.setRowCount(0);
			ResultSet rs = con.createStatement().executeQuery("SELECT * FROM user");
			while (rs.next()) {
				model.addRow(new Object[]{
						rs.getInt("userid"),
						rs.getString("username"),
						rs.getString("password"),
						rs.getString("role"),
						rs.getString("email")
				});
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
