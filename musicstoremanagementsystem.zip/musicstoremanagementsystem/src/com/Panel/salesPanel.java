package com.Panel;

import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import com.util.DB;

public class salesPanel extends JPanel implements ActionListener {

    private JTable table;
    private DefaultTableModel model;
    private JButton loadBtn = new JButton("Load");
    private JButton addBtn = new JButton("Add");
    private JButton updateBtn = new JButton("Update");
    private JButton deleteBtn = new JButton("Delete");

    private JTextField saleIdTxt = new JTextField();
    private JComboBox<String> productCmb = new JComboBox<>();
    private JComboBox<String> customerCmb = new JComboBox<>();
    private JTextField quantityTxt = new JTextField();
    private JTextField totalPriceTxt = new JTextField();

    private int currentUserId;
    private String role;
    private boolean isCustomerView = false;

    public salesPanel(int userId, String role) throws Exception {
        this.currentUserId = userId;
        this.role = role.toLowerCase();
        this.isCustomerView = role.equalsIgnoreCase("customer");

        setLayout(null);

        // Table columns include Stock Remaining
        String[] columns = {"SaleID", "Product", "Customer", "Quantity", "Total Price", "Sale Date", "Stock Remaining", "Created By"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int row = table.getSelectedRow();
                saleIdTxt.setText(model.getValueAt(row, 0).toString());
                productCmb.setSelectedItem(model.getValueAt(row, 1));
                customerCmb.setSelectedItem(model.getValueAt(row, 2));
                quantityTxt.setText(model.getValueAt(row, 3).toString());
                totalPriceTxt.setText(model.getValueAt(row, 4).toString());
            }
        });

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 230, 900, 300);
        add(sp);

        // Buttons
        loadBtn.setBounds(20, 20, 100, 30);
        add(loadBtn);
        loadBtn.addActionListener(this);

        if (role.equals("admin") || role.equals("staff") || role.equals("cashier")) {
            addBtn.setBounds(140, 20, 100, 30);
            updateBtn.setBounds(260, 20, 100, 30);
            deleteBtn.setBounds(380, 20, 100, 30);

            add(addBtn); add(updateBtn); add(deleteBtn);

            addBtn.addActionListener(this);
            updateBtn.addActionListener(this);
            deleteBtn.addActionListener(this);

            setupInputFields();
            loadProducts();
            loadCustomers();
        } else if (isCustomerView) {
            setupReadOnlyFields();
        }

        loadsale();
    }

    private void setupInputFields() {
        JLabel saleIdLbl = new JLabel("Sale ID:");
        saleIdLbl.setBounds(20, 60, 80, 25); add(saleIdLbl);
        saleIdTxt.setBounds(100, 60, 100, 25); saleIdTxt.setEditable(false); add(saleIdTxt);

        JLabel productLbl = new JLabel("Product:");
        productLbl.setBounds(220, 60, 80, 25); add(productLbl);
        productCmb.setBounds(300, 60, 150, 25); add(productCmb);

        JLabel customerLbl = new JLabel("Customer:");
        customerLbl.setBounds(470, 60, 80, 25); add(customerLbl);
        customerCmb.setBounds(550, 60, 150, 25); add(customerCmb);

        JLabel quantityLbl = new JLabel("Quantity:");
        quantityLbl.setBounds(20, 100, 80, 25); add(quantityLbl);
        quantityTxt.setBounds(100, 100, 100, 25); add(quantityTxt);

        JLabel totalPriceLbl = new JLabel("Total Price:");
        totalPriceLbl.setBounds(220, 100, 100, 25); add(totalPriceLbl);
        totalPriceTxt.setBounds(300, 100, 120, 25); add(totalPriceTxt);

        JButton clearBtn = new JButton("Clear");
        clearBtn.setBounds(450, 100, 80, 25); add(clearBtn);
        clearBtn.addActionListener(e -> clearFields());
    }

    private void setupReadOnlyFields() {
        JLabel infoLbl = new JLabel("Your Sales History:");
        infoLbl.setBounds(20, 60, 200, 25); add(infoLbl);
    }

    private void clearFields() {
        saleIdTxt.setText("");
        quantityTxt.setText("");
        totalPriceTxt.setText("");
        if (productCmb.getItemCount() > 0) productCmb.setSelectedIndex(0);
        if (customerCmb.getItemCount() > 0) customerCmb.setSelectedIndex(0);
        table.clearSelection();
    }

    private void loadProducts() throws Exception {
        try (Connection con = DB.getConnection()) {
            productCmb.removeAllItems(); productCmb.addItem("-- Select Product --");
            PreparedStatement ps = con.prepareStatement("SELECT ProductID, Name FROM Product ORDER BY Name");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) productCmb.addItem(rs.getInt("ProductID") + " - " + rs.getString("Name"));
        }
    }

    private void loadCustomers() throws Exception {
        try (Connection con = DB.getConnection()) {
            customerCmb.removeAllItems(); customerCmb.addItem("-- Select Customer --");
            PreparedStatement ps = con.prepareStatement("SELECT CustomerID, Name FROM customer ORDER BY Name");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) customerCmb.addItem(rs.getInt("CustomerID") + " - " + rs.getString("Name"));
        }
    }

    private int extractIdFromComboBox(JComboBox<String> comboBox) {
        String selected = (String) comboBox.getSelectedItem();
        if (selected != null && !selected.startsWith("--")) return Integer.parseInt(selected.split(" - ")[0]);
        return 0;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try (Connection con = DB.getConnection()) {
            if (e.getSource() == loadBtn) { loadsale(); return; }
            if (isCustomerView) return;

            int productId = extractIdFromComboBox(productCmb);
            int customerId = extractIdFromComboBox(customerCmb);
            int quantity = 0;
            double totalPrice = 0;

            if (!quantityTxt.getText().trim().isEmpty()) quantity = Integer.parseInt(quantityTxt.getText().trim());
            if (!totalPriceTxt.getText().trim().isEmpty()) totalPrice = Double.parseDouble(totalPriceTxt.getText().trim());

            if (e.getSource() == addBtn) {
                if (productId==0 || customerId==0) { JOptionPane.showMessageDialog(this,"Select product and customer!"); return; }

                // Check stock availability
                PreparedStatement stockCheck = con.prepareStatement("SELECT stock FROM Product WHERE ProductID=?");
                stockCheck.setInt(1, productId);
                ResultSet rs = stockCheck.executeQuery();
                if (rs.next() && rs.getInt("stock") < quantity) {
                    JOptionPane.showMessageDialog(this,"Not enough stock available!");
                    return;
                }

                // Insert sale
                String sql = "INSERT INTO sale (productid, customerid, userid, quantity, total_price, sale_date) VALUES (?,?,?,?,?,NOW())";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, productId); ps.setInt(2, customerId); ps.setInt(3, currentUserId);
                ps.setInt(4, quantity); ps.setDouble(5, totalPrice); ps.executeUpdate();

                // Reduce stock
                PreparedStatement updateStock = con.prepareStatement("UPDATE Product SET stock=stock-? WHERE ProductID=?");
                updateStock.setInt(1, quantity); updateStock.setInt(2, productId);
                updateStock.executeUpdate();

                JOptionPane.showMessageDialog(this,"Sale added successfully!");
                clearFields(); loadsale();

            } else if (e.getSource() == updateBtn) {
                if (saleIdTxt.getText().isEmpty()) { JOptionPane.showMessageDialog(this,"Select a sale to update!"); return; }
                int saleId = Integer.parseInt(saleIdTxt.getText());

                // Optional: You can implement stock adjustment when updating quantity if needed

                String sql = "UPDATE sale SET productid=?, customerid=?, quantity=?, total_price=? WHERE saleid=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, productId); ps.setInt(2, customerId); ps.setInt(3, quantity);
                ps.setDouble(4, totalPrice); ps.setInt(5, saleId); ps.executeUpdate();
                JOptionPane.showMessageDialog(this,"Sale updated successfully!");
                clearFields(); loadsale();

            } else if (e.getSource() == deleteBtn) {
                if (saleIdTxt.getText().isEmpty()) { JOptionPane.showMessageDialog(this,"Select a sale to delete!"); return; }
                int saleId = Integer.parseInt(saleIdTxt.getText());
                int confirm = JOptionPane.showConfirmDialog(this,"Are you sure you want to delete this sale?","Confirm Delete",JOptionPane.YES_NO_OPTION);
                if (confirm!=JOptionPane.YES_OPTION) return;

                // Restore stock when deleting a sale
                PreparedStatement getSale = con.prepareStatement("SELECT productid, quantity FROM sale WHERE saleid=?");
                getSale.setInt(1, saleId);
                ResultSet rs = getSale.executeQuery();
                if (rs.next()) {
                    int productIdDel = rs.getInt("productid");
                    int qtyDel = rs.getInt("quantity");
                    PreparedStatement restoreStock = con.prepareStatement("UPDATE Product SET stock=stock+? WHERE ProductID=?");
                    restoreStock.setInt(1, qtyDel);
                    restoreStock.setInt(2, productIdDel);
                    restoreStock.executeUpdate();
                }

                PreparedStatement ps = con.prepareStatement("DELETE FROM sale WHERE saleid=?");
                ps.setInt(1, saleId); ps.executeUpdate();
                JOptionPane.showMessageDialog(this,"Sale deleted successfully!");
                clearFields(); loadsale();
            }
        } catch(Exception ex){ ex.printStackTrace(); JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage()); }
    }

    private void loadsale() throws Exception {
        try (Connection con = DB.getConnection()) {
            model.setRowCount(0);
            String sql = "SELECT s.saleid, p.Name AS ProductName, c.Name AS CustomerName, s.quantity, s.total_price, s.sale_date, p.stock AS StockRemaining, u.Username AS CreatedBy " +
                         "FROM sale s " +
                         "LEFT JOIN Product p ON s.productid=p.ProductID " +
                         "LEFT JOIN customer c ON s.customerid=c.CustomerID " +
                         "LEFT JOIN user u ON s.userid=u.UserID " +
                         "ORDER BY s.sale_date DESC";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[] {
                    rs.getInt("saleid"),
                    rs.getString("ProductName"),
                    rs.getString("CustomerName"),
                    rs.getInt("quantity"),
                    rs.getDouble("total_price"),
                    rs.getTimestamp("sale_date"),
                    rs.getInt("StockRemaining"),
                    rs.getString("CreatedBy")
                });
            }
        }
    }
}
