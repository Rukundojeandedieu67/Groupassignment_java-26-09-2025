package com.form;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;

import com.util.DB;


public class LoginForm extends JFrame implements ActionListener {
    JTextField usertxt = new JTextField("Enter username");
    JPasswordField passtxt = new JPasswordField();
    
    JButton loginbtn = new JButton("Login");
    JButton cancelbtn = new JButton("Cancel");
    
    // Constructor
    public LoginForm() {
        setTitle("Music Store Login");
        setBounds(100, 100, 300, 200);
        setLayout(null);
        
        usertxt.setBounds(50, 30, 200, 25);
        passtxt.setBounds(50, 70, 200, 25);
        
        loginbtn.setBounds(30, 100, 120, 30);
        cancelbtn.setBounds(150, 100, 120, 30);
        
        add(usertxt);
        add(passtxt);
        add(loginbtn);
        add(cancelbtn);
        
        loginbtn.addActionListener(this);
        cancelbtn.addActionListener(this);
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // center window
        setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == cancelbtn) {
            dispose(); // close login form
            return;
        }
        
        if (e.getSource() == loginbtn) {
            String username = usertxt.getText();
            String password = new String(passtxt.getPassword());
            
            // Basic validation
            if (username.isEmpty() || username.equals("Enter username")) {
                JOptionPane.showMessageDialog(this, "Please enter username");
                return;
            } 
            if (password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter password");
                return;
            }
            
            // Database authentication
            try (Connection con = DB.getConnection()) {
                String sql = "SELECT * FROM User WHERE Username=? AND Password=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, username);
                ps.setString(2, password);
                ResultSet rs = ps.executeQuery();
                
                if (rs.next()) {
                    String role = rs.getString("Role");
                    int userid = rs.getInt("UserID");
                    dispose(); // close login window
                    new MSMS(role, userid); // open main music store system
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid username or password!", "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database connection error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}