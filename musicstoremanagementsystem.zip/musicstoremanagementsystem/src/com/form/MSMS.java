package com.form;

import java.awt.BorderLayout;
import javax.swing.*;

import com.Panel.*;

public class MSMS extends JFrame {

    public MSMS(String role, int userid) {
        JTabbedPane tabs = new JTabbedPane();
        setTitle("Music Store Management System");
        setSize(900, 600);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null); // Center the window

        try {
            // Admin access - full system access
            if ("admin".equalsIgnoreCase(role)) {
                tabs.add("Users", new UserPanel());
                tabs.add("Suppliers", new SupplierPanel());
                tabs.add("Products", new ProductPanel(userid));
                tabs.add("Customers", new CustomerPanel(userid));
                tabs.add("Sales", new salesPanel(userid, role));
                tabs.add("Payments", new PaymentPanel());

            } 
            // Staff access - manage products, customers, sales, payments
            else if ("staff".equalsIgnoreCase(role)) {
                tabs.add("Products", new ProductPanel(userid));
                tabs.add("Customers", new CustomerPanel(userid));
                tabs.add("Sales", new salesPanel(userid, role));
                tabs.add("Payments", new PaymentPanel());

            } 
            // Cashier access - handle sales and payments
            else if ("cashier".equalsIgnoreCase(role)) {
                tabs.add("Sales", new salesPanel(userid, role));
                tabs.add("Payments", new PaymentPanel());

            } 
            // Customer access - view own profile and purchases
            else if ("customer".equalsIgnoreCase(role)) {
                tabs.add("My Profile", new CustomerPanel(userid));
                tabs.add("My Purchases", new salesPanel(userid, role));

            } 
            // Default - minimal access
            else {
                tabs.add("Sales", new salesPanel(userid, role));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(
                this,
                "Error initializing panel: " + ex.getMessage(),
                "Initialization Error",
                JOptionPane.ERROR_MESSAGE
            );
        }

        add(tabs, BorderLayout.CENTER);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
}
