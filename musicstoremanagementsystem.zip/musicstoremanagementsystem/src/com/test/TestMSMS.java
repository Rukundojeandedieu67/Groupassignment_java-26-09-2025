package com.test;
import com.form.LoginForm;
import javax.swing.SwingUtilities;

public class TestMSMS {
    public static void main(String[] args) {
    	 LoginForm lgn =new  LoginForm();
    }
}