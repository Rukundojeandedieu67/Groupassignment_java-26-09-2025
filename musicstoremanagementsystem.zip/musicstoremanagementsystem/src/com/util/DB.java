package com.util;
import java.sql.Connection;
import java.sql.DriverManager;

public class DB {
    public static Connection getConnection() throws Exception {
        // Load MySQL JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");
        // Connect to database
        String url = "jdbc:mysql://localhost/msms";
        String user = "root";
        String password = "";
        return DriverManager.getConnection(url, user, password);
    }
}
